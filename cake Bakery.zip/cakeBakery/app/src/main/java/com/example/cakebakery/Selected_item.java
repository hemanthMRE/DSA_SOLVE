package com.example.cakebakery;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Selected_item extends AppCompatActivity {
    TextView tv;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tv=findViewById(R.id.result);
        Intent intent=getIntent();
        String item=intent.getStringExtra("ITEM");
        String dates=intent.getStringExtra("DATE");
        String times=intent.getStringExtra("TIME");
        tv.setText(item+"\n"+dates+"\n"+times);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_selected_item);

    }
}
