package com.example.cakebakery;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    Spinner sp;
    String[] items={"Vanilla","Strawberry","Chocolate","Oreo"};
    String dateSelected, timeSelected;
    String itemSelected;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        sp=findViewById(R.id.cakeBox);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(adapter);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                itemSelected = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                itemSelected = "Noting Selected";
            }
        });
    }

    public void bringDate(View v) {
        Calendar c=Calendar.getInstance();
        int pYear=c.get(Calendar.YEAR);
        int pMonth=c.get(Calendar.MONTH);
        int pDate=c.get(Calendar.DATE);

        DatePickerDialog dialog = new DatePickerDialog(this, android.R.style.Theme_DeviceDefault_DialogWhenLarge, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                dateSelected = pDate+"/"+(pMonth+1)+"/"+pYear;
            }
        },pYear,pMonth,pDate);
        dialog.show();

    }
    public void bringTime(View v) {
        Calendar c = Calendar.getInstance();
        int pHour = c.get(Calendar.HOUR_OF_DAY);
        int pMinute = c.get(Calendar.MINUTE);
        int pSecond = c.get(Calendar.SECOND);
        TimePickerDialog timeDialog = new TimePickerDialog(this, android.R.style.Theme_DeviceDefault_DialogWhenLarge, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int i, int i1) {
                timeSelected = i+":"+i1;
            }
        },pHour, pMinute, false);

        timeDialog.show();
    }

    public void placeOrder(View v) {
        Intent intent = new Intent(getApplicationContext(), Selected_item.class );
        intent.putExtra("ITEM", itemSelected);
        intent.putExtra("DATE", dateSelected);
        intent.putExtra("TIME",timeSelected);
        startActivity(intent);
    }
}