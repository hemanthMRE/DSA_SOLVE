package com.example.experiment9;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    ImageView p,s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        p=findViewById(R.id.musicPlay);
        s=findViewById(R.id.musicStop);

    }
    public void playMusic(View v) {
        startService(new Intent(this,MyService.class));
    }
    public void stopMusic(View v) {
        stopService(new Intent(this,MyService.class));
    }
}