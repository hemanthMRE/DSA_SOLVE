package com.example.experiment9;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class MyService extends Service {
    MediaPlayer mp;
    public MyService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
    public int onStartCommand(Intent intent, int flags, int startId) {
        mp = MediaPlayer.create(this,R.raw.chorus);

        Toast.makeText(this,"playing",Toast.LENGTH_SHORT).show();
        if (mp != null) {
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.setLooping(true);
                    mp.start();  // Start playback when prepared
                }
            });
            mp.setLooping(true);
            mp.start();  // If already prepared, start playback immediately
        } else {
            Log.e("MyService", "MediaPlayer initialization failed.");
        }

        return START_STICKY;
    }
    public void onDestroy(){
        super.onDestroy();
        mp.stop();
    }
}