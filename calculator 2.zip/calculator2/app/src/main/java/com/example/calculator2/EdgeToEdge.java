package com.example.calculator2;

public class EdgeToEdge {
}
